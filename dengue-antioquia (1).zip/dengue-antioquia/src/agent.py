"""Agente LLM con loop agéntico manual (razonar -> llamar herramienta -> observar), Tmáx de
iteraciones y errores de herramientas devueltos como observación.

LLM: cualquier endpoint compatible con OpenAI (Groq, NVIDIA NIM, Ollama). Variables de entorno:
  LLM_API_KEY, LLM_BASE_URL (def. https://api.groq.com/openai/v1), LLM_MODEL (def. llama-3.3-70b-versatile)
Sin API key el agente usa un modo OFFLINE (enrutador por reglas) para que la demo nunca falle.
"""
from __future__ import annotations

import json
import os
import re

from src.data import MUNICIPIOS, canonical_municipio
from src.rag import Retriever

T_MAX = 6
SYSTEM = (
    "Eres un asistente de vigilancia de dengue para Antioquia (Colombia). Usa SIEMPRE las "
    "herramientas: get_risk para riesgo de un municipio, get_cases para casos/tendencia, "
    "search_docs para protocolos y conceptos. Cita los documentos como [archivo]. Responde en "
    "español, breve. Aclara que es una herramienta analítica, no consejo médico."
)

TOOLS_SCHEMA = [
    {"type": "function", "function": {
        "name": "get_risk", "description": "Probabilidad de brote la próxima semana en un municipio (red bayesiana).",
        "parameters": {"type": "object", "properties": {"municipio": {"type": "string"}}, "required": ["municipio"]}}},
    {"type": "function", "function": {
        "name": "get_cases", "description": "Casos semanales recientes y tendencia de un municipio.",
        "parameters": {"type": "object", "properties": {"municipio": {"type": "string"},
                                                        "semanas": {"type": "integer", "default": 8}},
                       "required": ["municipio"]}}},
    {"type": "function", "function": {
        "name": "search_docs", "description": "Busca en protocolos INS/OPS y guías de vigilancia (RAG).",
        "parameters": {"type": "object", "properties": {"query": {"type": "string"}}, "required": ["query"]}}},
]


class Tools:
    def __init__(self, bn, df):
        self.bn, self.df, self.ret = bn, df, Retriever()

    def _mun(self, m):
        c = canonical_municipio(m or "")
        if c is None or c not in set(self.df["municipio"]):
            raise ValueError(f"Municipio '{m}' no encontrado. Disponibles: {', '.join(sorted(self.df['municipio'].unique()))}")
        return c

    def get_risk(self, municipio: str):
        mun = self._mun(municipio)
        last = self.df[self.df["municipio"] == mun].iloc[-1]
        ev = {k: last[k] for k in ["Lluvia", "Temp", "Temporada", "Historial"]}
        p = self.bn.query("Brote", ev)["si"]
        nivel = "alto" if p >= 0.6 else "medio" if p >= 0.3 else "bajo"
        return {"municipio": mun, "semana": f"{int(last.anio)}-S{int(last.semana)}",
                "prob_brote_proxima_semana": round(p, 3), "nivel": nivel, "evidencia": ev,
                "umbral_brote_casos": float(last.umbral_brote), "fuente": "modelo red bayesiana (src/bayes_net.py)"}

    def get_cases(self, municipio: str, semanas: int = 8):
        mun = self._mun(municipio)
        d = self.df[self.df["municipio"] == mun].tail(int(semanas))
        c = d["casos"].tolist()
        h = len(c) // 2
        tend = "en aumento" if sum(c[h:]) > sum(c[:h]) * 1.1 else "en descenso" if sum(c[h:]) < sum(c[:h]) * 0.9 else "estable"
        return {"municipio": mun, "semanas": [f"{int(a)}-S{int(s)}" for a, s in zip(d.anio, d.semana)],
                "casos": c, "tendencia": tend, "fuente": "datos agregados SIVIGILA/INS (ver README)"}

    def search_docs(self, query: str):
        r = self.ret.search(query, k=3)
        if not r:
            return {"resultados": [], "nota": "Sin documentos relevantes"}
        return {"resultados": [{"doc": x["doc"], "texto": x["text"][:600]} for x in r]}

    def call(self, name, args):
        try:
            return getattr(self, name)(**args)
        except Exception as e:  # el error vuelve al agente como observación
            return {"error": str(e)}


class Agent:
    def __init__(self, tools: Tools):
        self.tools = tools
        self.key = os.getenv("LLM_API_KEY") or os.getenv("GROQ_API_KEY")
        self.client = None
        if self.key:
            from openai import OpenAI
            self.client = OpenAI(api_key=self.key, base_url=os.getenv("LLM_BASE_URL", "https://api.groq.com/openai/v1"))
            self.model = os.getenv("LLM_MODEL", "llama-3.3-70b-versatile")

    @property
    def mode(self):
        return "LLM" if self.client else "offline"

    def run(self, question: str) -> dict:
        """Devuelve {'answer', 'trace': [(tool, args, observation)]}."""
        if self.client:
            try:
                return self._run_llm(question)
            except Exception as e:
                out = self._run_offline(question)
                out["answer"] = f"(LLM no disponible: {e}. Respuesta en modo offline)\n\n" + out["answer"]
                return out
        return self._run_offline(question)

    def _run_llm(self, question):
        msgs = [{"role": "system", "content": SYSTEM}, {"role": "user", "content": question}]
        trace = []
        for _ in range(T_MAX):
            r = self.client.chat.completions.create(model=self.model, messages=msgs, tools=TOOLS_SCHEMA,
                                                    tool_choice="auto", temperature=0)
            msg = r.choices[0].message
            if not msg.tool_calls:
                return {"answer": msg.content, "trace": trace}
            msgs.append({"role": "assistant", "content": msg.content or "",
                         "tool_calls": [tc.model_dump() for tc in msg.tool_calls]})
            for tc in msg.tool_calls:
                try:
                    args = json.loads(tc.function.arguments or "{}")
                except json.JSONDecodeError:
                    args = {}
                obs = self.tools.call(tc.function.name, args)
                trace.append((tc.function.name, args, obs))
                msgs.append({"role": "tool", "tool_call_id": tc.id, "content": json.dumps(obs, ensure_ascii=False, default=str)})
        return {"answer": "Se alcanzó el máximo de iteraciones (Tmáx).", "trace": trace}

    # ---------- modo offline: enrutador por reglas, mismas herramientas y citas
    def _run_offline(self, q):
        ql = q.lower()
        from src.data import _norm
        qn = _norm(q)
        mun = next((m for m in sorted(MUNICIPIOS, key=len, reverse=True) if _norm(m) in qn), None)
        trace, parts = [], []
        if mun and any(w in ql for w in ["riesgo", "brote", "probab", "alerta", "peligro"]):
            o = self.tools.call("get_risk", {"municipio": mun}); trace.append(("get_risk", {"municipio": mun}, o))
            if "error" not in o:
                parts.append(f"Riesgo de brote en {o['municipio']} para la semana siguiente a {o['semana']}: "
                             f"{o['prob_brote_proxima_semana']:.0%} (nivel {o['nivel']}). Evidencia: {o['evidencia']}. "
                             f"[modelo red bayesiana]")
        if mun and any(w in ql for w in ["caso", "tendencia", "semana", "cuánt", "cuant"]):
            o = self.tools.call("get_cases", {"municipio": mun}); trace.append(("get_cases", {"municipio": mun}, o))
            if "error" not in o:
                parts.append(f"Casos últimas {len(o['casos'])} semanas en {o['municipio']}: {o['casos']} "
                             f"(tendencia {o['tendencia']}). [datos SIVIGILA agregados]")
        if not parts or any(w in ql for w in ["qué", "que ", "cómo", "como", "protocolo", "signo", "prevenir", "canal", "por qué"]):
            o = self.tools.call("search_docs", {"query": q}); trace.append(("search_docs", {"query": q}, o))
            for r in o.get("resultados", [])[:2]:
                parts.append(f"{r['texto'][:350]}… [{r['doc']}]")
        if not parts:
            parts.append("No encontré información para responder. Prueba indicando un municipio de Antioquia.")
        parts.append("_Herramienta analítica, no consejo médico._")
        return {"answer": "\n\n".join(parts), "trace": trace}
