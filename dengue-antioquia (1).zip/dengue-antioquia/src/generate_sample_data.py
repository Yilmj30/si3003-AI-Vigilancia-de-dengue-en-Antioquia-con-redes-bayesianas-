"""Genera una muestra SINTÉTICA (NO real) solo para probar el pipeline de punta a punta
cuando aún no se han descargado los datos reales. La app la marca visiblemente como sintética.
Reemplazar por data/raw/dengue_antioquia.csv (ver README)."""
import os

import numpy as np
import pandas as pd

from src.data import MUNICIPIOS, PROC


def main(seed: int = 42):
    rng = np.random.default_rng(seed)
    parts = []
    for mun in MUNICIPIOS:
        base = 0.4 if mun == "Rionegro" else rng.uniform(1, 12)
        rain_m, temp_m = rng.uniform(80, 250), rng.uniform(22, 29)
        n = 9 * 52
        anio = np.repeat(np.arange(2016, 2025), 52)
        sem = np.tile(np.arange(1, 53), 9)
        rain = np.clip(rain_m * (1 + 0.6 * np.sin(2 * np.pi * (sem - 10) / 26)) + rng.normal(0, 30, n), 0, None)
        temp = temp_m + 1.2 * np.sin(2 * np.pi * (sem - 8) / 52) + rng.normal(0, 0.6, n)
        casos, prev = np.zeros(n, int), base
        for k in range(n):
            lo, hi = max(0, k - 5), max(1, k - 2)
            r, t = rain[lo:hi].mean(), temp[lo:hi].mean()
            boost = 2.5 if anio[k] in (2019, 2023) else 1.0
            lam = base * boost * np.exp(0.004 * (r - rain_m) + 0.3 * (t - temp_m)) * 0.6 + 0.4 * prev
            casos[k] = rng.poisson(max(lam, 0.05))
            prev = casos[k]
        parts.append(pd.DataFrame({"municipio": mun, "anio": anio, "semana": sem,
                                   "precipitacion_mm": rain.round(1), "temperatura_c": temp.round(2),
                                   "casos": casos}))
    out = pd.concat(parts)
    os.makedirs(PROC, exist_ok=True)
    out.to_csv(os.path.join(PROC, "sample_synthetic.csv"), index=False)
    print("Muestra SINTÉTICA guardada:", len(out), "filas")


if __name__ == "__main__":
    main()
