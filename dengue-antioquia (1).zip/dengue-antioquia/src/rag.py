"""RAG ligero: fragmentación de documentos de docs/ (.md, .txt, .pdf) + recuperación TF-IDF
(coseno). No requiere descargar modelos, por lo que corre igual en cualquier máquina."""
from __future__ import annotations

import glob
import os

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from src.data import ROOT

DOCS = os.path.join(ROOT, "docs")


def _read(path: str) -> str:
    if path.endswith(".pdf"):
        from pypdf import PdfReader
        return "\n".join(p.extract_text() or "" for p in PdfReader(path).pages)
    with open(path, encoding="utf-8", errors="ignore") as f:
        return f.read()


class Retriever:
    def __init__(self, chunk_words: int = 120, overlap: int = 30):
        self.chunks = []
        for p in sorted(glob.glob(os.path.join(DOCS, "*"))):
            if not p.endswith((".md", ".txt", ".pdf")):
                continue
            words = _read(p).split()
            step = chunk_words - overlap
            for i in range(0, max(len(words), 1), step):
                txt = " ".join(words[i:i + chunk_words])
                if txt.strip():
                    self.chunks.append({"doc": os.path.basename(p), "text": txt})
        self.vec = TfidfVectorizer(strip_accents="unicode", lowercase=True)
        self.X = self.vec.fit_transform([c["text"] for c in self.chunks])

    def search(self, query: str, k: int = 3) -> list[dict]:
        sims = cosine_similarity(self.vec.transform([query]), self.X).ravel()
        idx = sims.argsort()[::-1][:k]
        return [dict(self.chunks[i], score=round(float(sims[i]), 3)) for i in idx if sims[i] > 0]
