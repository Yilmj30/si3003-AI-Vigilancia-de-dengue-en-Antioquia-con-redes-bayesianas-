"""Entrenamiento con validación temporal y comparación contra líneas base.
Ejecutar:  python -m src.model
"""
from __future__ import annotations

import json
import os

import numpy as np
import pandas as pd
from sklearn.metrics import brier_score_loss, f1_score, roc_auc_score

from src.bayes_net import BayesNet
from src.data import PROC, add_thresholds, load_raw, prepare

TEST_FROM_YEAR = 2023  # entrenamiento: años < 2023 ; prueba: 2023 en adelante


def build():
    raw, origen = load_raw()
    df = prepare(raw)
    train_mask = df["anio"] < TEST_FROM_YEAR
    df = add_thresholds(df, train_mask)
    df = df.dropna(subset=["casos_sig"])
    train, test = df[df["anio"] < TEST_FROM_YEAR], df[df["anio"] >= TEST_FROM_YEAR]
    bn = BayesNet(alpha=1.0).fit(train)
    return bn, df, train, test, origen


def evaluate(bn, train, test) -> dict:
    y = (test["Brote"] == "si").astype(int).values
    p_bn = bn.predict_proba(test)
    # Línea base 1: persistencia (si esta semana hay brote, la próxima también)
    p_pers = (test["Brote_actual"] == "si").astype(float).values
    # Línea base 2: tasa histórica de brote por municipio (climatología)
    rate = (train["Brote"] == "si").groupby(train["municipio"]).mean()
    p_clim = test["municipio"].map(rate).fillna(rate.mean()).values
    # Ablación: red sin clima (Lluvia/Temp marginalizadas)
    p_noclim = bn.predict_proba(test.assign(Lluvia=None, Temp=None))

    def m(p, thr=0.5):
        return {"AUC": round(roc_auc_score(y, p), 3) if len(set(p)) > 1 else 0.5,
                "F1": round(f1_score(y, (p >= thr).astype(int)), 3),
                "Brier": round(brier_score_loss(y, np.clip(p, 0, 1)), 3)}
    return {"n_test": int(len(y)), "prevalencia_brote": round(float(y.mean()), 3),
            "Red bayesiana": m(p_bn), "Red sin clima (ablación)": m(p_noclim),
            "Base: persistencia": m(p_pers), "Base: tasa histórica municipal": m(p_clim)}


if __name__ == "__main__":
    bn, df, train, test, origen = build()
    res = evaluate(bn, train, test)
    res["origen_datos"] = origen
    os.makedirs(PROC, exist_ok=True)
    with open(os.path.join(PROC, "metricas.json"), "w", encoding="utf-8") as f:
        json.dump(res, f, ensure_ascii=False, indent=2)
    print(json.dumps(res, ensure_ascii=False, indent=2))
    print(bn.cpt_table("Brote").to_string())
