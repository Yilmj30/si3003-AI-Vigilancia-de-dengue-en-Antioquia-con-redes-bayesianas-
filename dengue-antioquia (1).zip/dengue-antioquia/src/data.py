"""Carga y preparación de datos agregados (municipio-semana) de dengue en Antioquia.

Prioridad de fuentes:
  1. data/raw/dengue_antioquia.csv  -> datos REALES agregados (ver README para obtenerlos
     de SIVIGILA/INS y de IDEAM/SIATA). Columnas: municipio, anio, semana, casos,
     precipitacion_mm, temperatura_c
  2. data/raw/sivigila_*.csv        -> microdatos SIVIGILA (evento 210/220); se agregan
     de inmediato por municipio-semana y solo se conservan los conteos.
  3. data/processed/sample_synthetic.csv -> muestra SINTÉTICA solo para probar el pipeline.
"""
from __future__ import annotations

import glob
import os
import unicodedata

import numpy as np
import pandas as pd

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RAW = os.path.join(ROOT, "data", "raw")
PROC = os.path.join(ROOT, "data", "processed")

# Coordenadas aproximadas de cabeceras municipales (para el mapa)
MUNICIPIOS = {
    "Medellín": (6.2442, -75.5812), "Bello": (6.3373, -75.5580), "Itagüí": (6.1719, -75.6114),
    "Envigado": (6.1759, -75.5917), "Apartadó": (7.8829, -76.6258), "Turbo": (8.0926, -76.7282),
    "Carepa": (7.7586, -76.6553), "Chigorodó": (7.6666, -76.6810), "Necoclí": (8.4260, -76.7840),
    "Caucasia": (7.9864, -75.1933), "El Bagre": (7.5975, -74.8080), "Zaragoza": (7.4890, -74.8680),
    "Nechí": (8.0940, -74.7760), "Cáceres": (7.5780, -75.3520), "Segovia": (7.0790, -74.7010),
    "Puerto Berrío": (6.4910, -74.4040), "Puerto Nare": (6.1910, -74.5860),
    "Puerto Triunfo": (5.8720, -74.6410), "Yondó": (7.0040, -73.9120),
    "Santa Fe de Antioquia": (6.5560, -75.8270), "Sopetrán": (6.5010, -75.7430),
    "Rionegro": (6.1550, -75.3740),
}


def _norm(s: str) -> str:
    s = unicodedata.normalize("NFKD", str(s)).encode("ascii", "ignore").decode()
    return s.strip().lower()


NORM2NAME = {_norm(k): k for k in MUNICIPIOS}


def canonical_municipio(name: str) -> str | None:
    n = _norm(name)
    if n in NORM2NAME:
        return NORM2NAME[n]
    for k, v in NORM2NAME.items():
        if n and (n in k or k in n):
            return v
    return None


def _aggregate_sivigila(path: str) -> pd.DataFrame:
    """Agrega microdatos SIVIGILA a conteos municipio-semana (no se guarda nada individual)."""
    df = pd.read_csv(path, sep=None, engine="python", encoding_errors="ignore")
    cols = {c.lower(): c for c in df.columns}
    dep = cols.get("departamento_ocurrencia") or cols.get("ndep_proce") or cols.get("departamento")
    mun = cols.get("municipio_ocurrencia") or cols.get("nmun_proce") or cols.get("municipio")
    ano = cols.get("ano") or cols.get("año") or cols.get("anio")
    sem = cols.get("semana")
    if dep:
        df = df[df[dep].astype(str).map(_norm).str.contains("antioquia")]
    out = (df.groupby([df[mun], df[ano], df[sem]]).size()
             .reset_index(name="casos"))
    out.columns = ["municipio", "anio", "semana", "casos"]
    return out


def load_raw() -> tuple[pd.DataFrame, str]:
    real = os.path.join(RAW, "dengue_antioquia.csv")
    if os.path.exists(real):
        return pd.read_csv(real), "real"
    siv = sorted(glob.glob(os.path.join(RAW, "sivigila_*.csv")))
    if siv:
        df = pd.concat([_aggregate_sivigila(p) for p in siv])
        clima = os.path.join(RAW, "clima_municipio_semana.csv")
        if os.path.exists(clima):
            df = df.merge(pd.read_csv(clima), on=["municipio", "anio", "semana"], how="left")
        return df, "real"
    sample = os.path.join(PROC, "sample_synthetic.csv")
    if not os.path.exists(sample):
        from src.generate_sample_data import main as gen
        gen()
    return pd.read_csv(sample), "sintetico"


def prepare(df: pd.DataFrame) -> pd.DataFrame:
    """Limpia, ordena y crea variables discretas para la red bayesiana."""
    df = df.copy()
    df["municipio"] = df["municipio"].map(lambda x: canonical_municipio(x) or str(x).title())
    df = df.groupby(["municipio", "anio", "semana"], as_index=False).agg(
        casos=("casos", "sum"),
        precipitacion_mm=("precipitacion_mm", "mean") if "precipitacion_mm" in df else ("casos", lambda s: np.nan),
        temperatura_c=("temperatura_c", "mean") if "temperatura_c" in df else ("casos", lambda s: np.nan),
    )
    df = df.sort_values(["municipio", "anio", "semana"]).reset_index(drop=True)
    df["t"] = df["anio"] * 100 + df["semana"]
    g = df.groupby("municipio")
    # Rezagos: el clima afecta al vector con ~2-4 semanas de retraso
    df["lluvia_lag"] = g["precipitacion_mm"].transform(lambda s: s.shift(3).rolling(3, min_periods=1).mean())
    df["temp_lag"] = g["temperatura_c"].transform(lambda s: s.shift(3).rolling(3, min_periods=1).mean())
    df["casos_prev"] = g["casos"].transform(lambda s: s.shift(1).rolling(2, min_periods=1).mean())
    df["casos_sig"] = g["casos"].shift(-1)  # objetivo: casos de la próxima semana
    return df


def add_thresholds(df: pd.DataFrame, train_mask: pd.Series) -> pd.DataFrame:
    """Umbrales por municipio calculados SOLO con entrenamiento (evita fuga temporal)."""
    df = df.copy()
    tr = df[train_mask]
    q = tr.groupby("municipio").agg(
        umbral_brote=("casos", lambda s: max(s.quantile(0.75), 1)),
        med_casos=("casos", "median"),
        med_lluvia=("lluvia_lag", "median"),
        med_temp=("temp_lag", "median"),
    )
    df = df.drop(columns=[c for c in q.columns if c in df], errors="ignore").join(q, on="municipio")
    df["Lluvia"] = np.where(df["lluvia_lag"].isna(), None,
                            np.where(df["lluvia_lag"] > df["med_lluvia"], "alta", "baja"))
    df["Temp"] = np.where(df["temp_lag"].isna(), None,
                          np.where(df["temp_lag"] > df["med_temp"], "alta", "baja"))
    df["Temporada"] = np.where(df["semana"].isin(list(range(1, 14)) + list(range(40, 54))), "lluviosa_pico", "otra")
    df["Historial"] = np.where(df["casos_prev"] > df["umbral_brote"], "alto", "bajo")
    df["Brote"] = np.where(df["casos_sig"] > df["umbral_brote"], "si", "no")
    df["Brote_actual"] = np.where(df["casos"] > df["umbral_brote"], "si", "no")
    return df
