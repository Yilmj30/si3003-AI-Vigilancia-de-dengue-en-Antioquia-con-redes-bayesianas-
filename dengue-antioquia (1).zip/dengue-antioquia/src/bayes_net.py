"""Red bayesiana discreta implementada desde cero (sin pgmpy):
  - Aprendizaje de CPTs por máxima verosimilitud con suavizado de Laplace.
  - Inferencia exacta por ELIMINACIÓN DE VARIABLES sobre factores.

Estructura (DAG):
    Lluvia ──┐
             ├──> Clima ──┐
    Temp ────┘            │
    Temporada ────────────┼──> Brote
    Historial ────────────┘

Clima ("favorable para el vector") es una variable latente-derivada: favorable si lluvia y
temperatura rezagadas son altas. Brote = casos de la semana siguiente > umbral municipal (p75).
"""
from __future__ import annotations

import itertools
from dataclasses import dataclass, field

import numpy as np
import pandas as pd

DOMAINS = {
    "Lluvia": ["alta", "baja"],
    "Temp": ["alta", "baja"],
    "Clima": ["favorable", "desfavorable"],
    "Temporada": ["lluviosa_pico", "otra"],
    "Historial": ["alto", "bajo"],
    "Brote": ["si", "no"],
}
PARENTS = {
    "Lluvia": [], "Temp": [], "Temporada": [], "Historial": [],
    "Clima": ["Lluvia", "Temp"],
    "Brote": ["Clima", "Temporada", "Historial"],
}


# ---------------------------------------------------------------- factores
@dataclass
class Factor:
    vars: list[str]
    table: np.ndarray  # un eje por variable, en el orden de DOMAINS

    def reduce(self, evidence: dict) -> "Factor":
        idx, keep = [], []
        for v in self.vars:
            if v in evidence:
                idx.append(DOMAINS[v].index(evidence[v]))
            else:
                idx.append(slice(None)); keep.append(v)
        return Factor(keep, self.table[tuple(idx)])

    def multiply(self, other: "Factor") -> "Factor":
        allv = list(dict.fromkeys(self.vars + other.vars))
        letters = {v: chr(97 + i) for i, v in enumerate(allv)}
        expr = f"{''.join(letters[v] for v in self.vars)},{''.join(letters[v] for v in other.vars)}->{''.join(letters[v] for v in allv)}"
        return Factor(allv, np.einsum(expr, self.table, other.table))

    def sum_out(self, var: str) -> "Factor":
        i = self.vars.index(var)
        return Factor([v for v in self.vars if v != var], self.table.sum(axis=i))


@dataclass
class BayesNet:
    alpha: float = 1.0
    cpts: dict = field(default_factory=dict)

    def fit(self, df: pd.DataFrame) -> "BayesNet":
        df = df.copy()
        df["Clima"] = np.where((df["Lluvia"] == "alta") & (df["Temp"] == "alta"), "favorable", "desfavorable")
        for var, pars in PARENTS.items():
            sub = df.dropna(subset=[var] + pars)
            shape = [len(DOMAINS[p]) for p in pars] + [len(DOMAINS[var])]
            counts = np.full(shape, self.alpha, dtype=float)
            for combo in itertools.product(*[range(len(DOMAINS[p])) for p in pars]):
                m = np.ones(len(sub), bool)
                for p, k in zip(pars, combo):
                    m &= (sub[p] == DOMAINS[p][k]).values
                vc = sub.loc[m, var].value_counts()
                for j, val in enumerate(DOMAINS[var]):
                    counts[combo + (j,)] += vc.get(val, 0)
            probs = counts / counts.sum(axis=-1, keepdims=True)
            self.cpts[var] = Factor(pars + [var], probs)
        return self

    def query(self, target: str, evidence: dict) -> dict:
        """P(target | evidencia) por eliminación de variables. Evidencia faltante (None) se marginaliza."""
        ev = {k: v for k, v in evidence.items() if v is not None and not (isinstance(v, float) and np.isnan(v))}
        factors = [f.reduce(ev) for f in self.cpts.values()]
        hidden = [v for v in DOMAINS if v != target and v not in ev]
        # orden de eliminación: primero variables con menos factores (heurística min-degree simple)
        hidden.sort(key=lambda v: sum(v in f.vars for f in factors))
        for h in hidden:
            rel = [f for f in factors if h in f.vars]
            if not rel:
                continue
            prod = rel[0]
            for f in rel[1:]:
                prod = prod.multiply(f)
            factors = [f for f in factors if h not in f.vars] + [prod.sum_out(h)]
        res = factors[0]
        for f in factors[1:]:
            res = res.multiply(f)
        p = res.table / res.table.sum()
        return dict(zip(DOMAINS[target], p.ravel()))

    def predict_proba(self, df: pd.DataFrame) -> np.ndarray:
        cols = ["Lluvia", "Temp", "Temporada", "Historial"]
        cache, out = {}, []
        for row in df[cols].itertuples(index=False):
            key = tuple(row)
            if key not in cache:
                cache[key] = self.query("Brote", dict(zip(cols, key)))["si"]
            out.append(cache[key])
        return np.array(out)

    def cpt_table(self, var: str) -> pd.DataFrame:
        f = self.cpts[var]
        pars = f.vars[:-1]
        rows = []
        for combo in itertools.product(*[DOMAINS[p] for p in pars]):
            idx = tuple(DOMAINS[p].index(c) for p, c in zip(pars, combo))
            rows.append(dict(zip(pars, combo), **{f"P({var}={v})": round(float(f.table[idx][j]), 3)
                                                  for j, v in enumerate(DOMAINS[var])}))
        return pd.DataFrame(rows)
