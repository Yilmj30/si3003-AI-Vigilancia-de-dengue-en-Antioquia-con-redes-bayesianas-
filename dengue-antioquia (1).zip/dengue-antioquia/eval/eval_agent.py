"""Evaluación del agente con preguntas fijas: ¿llamó la herramienta correcta? ¿citó la fuente?
Ejecutar:  python -m eval.eval_agent   -> eval/resultados_agente.csv
"""
import os

import pandas as pd

from src.agent import Agent, Tools
from src.model import build

QUESTIONS = [
    ("¿Cuál es el riesgo de brote en Apartadó?", "get_risk"),
    ("¿Hay alerta de brote de dengue en Turbo?", "get_risk"),
    ("Probabilidad de brote en Caucasia la próxima semana", "get_risk"),
    ("¿Qué riesgo de brote tiene Rionegro?", "get_risk"),
    ("¿Cuántos casos ha tenido Medellín en las últimas semanas?", "get_cases"),
    ("Tendencia de casos en Puerto Berrío", "get_cases"),
    ("Casos recientes en Necoclí", "get_cases"),
    ("¿Qué es el canal endémico?", "search_docs"),
    ("¿Cuáles son los signos de alarma del dengue?", "search_docs"),
    ("¿Cómo prevenir los criaderos del mosquito?", "search_docs"),
    ("¿Por qué la lluvia aumenta el dengue?", "search_docs"),
    ("¿Cada cuánto se notifica el dengue en SIVIGILA?", "search_docs"),
    ("¿Cuál es el riesgo de brote en Bogotá?", "get_risk"),  # municipio fuera de cobertura: debe manejar el error
]


def main():
    bn, df, *_ = build()
    ag = Agent(Tools(bn, df))
    rows = []
    for q, exp in QUESTIONS:
        out = ag.run(q)
        called = [t[0] for t in out["trace"]]
        ans = out["answer"] or ""
        rows.append({"pregunta": q, "herramienta_esperada": exp, "herramientas_llamadas": ",".join(called),
                     "herramienta_correcta": exp in called, "cita_fuente": "[" in ans and "]" in ans,
                     "modo": ag.mode})
    r = pd.DataFrame(rows)
    os.makedirs("eval", exist_ok=True)
    r.to_csv("eval/resultados_agente.csv", index=False)
    print(r.to_string())
    print(f"\nHerramienta correcta: {r.herramienta_correcta.mean():.0%} | Cita fuente: {r.cita_fuente.mean():.0%}")


if __name__ == "__main__":
    main()
