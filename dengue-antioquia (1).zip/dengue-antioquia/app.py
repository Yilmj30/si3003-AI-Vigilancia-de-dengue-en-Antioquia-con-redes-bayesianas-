"""Dashboard Streamlit – Vigilancia de dengue en Antioquia con redes bayesianas + agente RAG.
Ejecutar:  streamlit run app.py
"""
import pandas as pd
import plotly.express as px
import streamlit as st

from src.agent import Agent, Tools
from src.data import MUNICIPIOS
from src.model import build, evaluate

st.set_page_config(page_title="Dengue Antioquia – Red bayesiana", layout="wide")


@st.cache_resource
def load():
    bn, df, train, test, origen = build()
    return bn, df, evaluate(bn, train, test), origen


bn, df, metrics, origen = load()
st.title("🦟 Vigilancia de dengue en Antioquia")
st.caption("Red bayesiana (eliminación de variables) + agente LLM con RAG. Herramienta analítica, NO guía clínica. Solo datos agregados.")
if origen == "sintetico":
    st.error("⚠️ Usando muestra SINTÉTICA para probar el pipeline. Coloque los datos reales en data/raw/ (ver README).")

# ---------------- controles
semanas = df[["anio", "semana"]].drop_duplicates().sort_values(["anio", "semana"])
labels = [f"{a}-S{s:02d}" for a, s in semanas.values]
c1, c2, c3 = st.columns([1, 1, 2])
mun = c1.selectbox("Municipio", sorted(df["municipio"].unique()), index=sorted(df["municipio"].unique()).index("Apartadó") if "Apartadó" in set(df["municipio"]) else 0)
sem_lbl = c2.select_slider("Semana epidemiológica", options=labels, value=labels[-1])
anio, sem = int(sem_lbl[:4]), int(sem_lbl[-2:])
escenario = c3.radio("Escenario climático (qué pasaría si…)", ["Observado", "Lluvia y temperatura altas", "Lluvia y temperatura bajas"], horizontal=True)

snap = df[(df["anio"] == anio) & (df["semana"] == sem)].copy()


def risk(row):
    ev = {k: row[k] for k in ["Lluvia", "Temp", "Temporada", "Historial"]}
    if escenario == "Lluvia y temperatura altas":
        ev.update(Lluvia="alta", Temp="alta")
    elif escenario == "Lluvia y temperatura bajas":
        ev.update(Lluvia="baja", Temp="baja")
    return bn.query("Brote", ev)["si"]


snap["prob_brote"] = snap.apply(risk, axis=1)
snap["lat"] = snap["municipio"].map(lambda m: MUNICIPIOS.get(m, (None, None))[0])
snap["lon"] = snap["municipio"].map(lambda m: MUNICIPIOS.get(m, (None, None))[1])

tab1, tab2, tab3 = st.tabs(["🗺️ Mapa y tendencia", "📊 Modelo y evaluación", "💬 Agente"])
with tab1:
    a, b = st.columns([1.1, 1])
    fig = px.scatter_map(snap.dropna(subset=["lat"]), lat="lat", lon="lon", color="prob_brote", size=snap.dropna(subset=["lat"])["casos"] + 3,
                            hover_name="municipio", hover_data={"casos": True, "prob_brote": ":.2f", "lat": False, "lon": False},
                            color_continuous_scale="YlOrRd", range_color=(0, 1), zoom=6.3, center={"lat": 7.0, "lon": -75.4},
                            map_style="open-street-map", height=520, title=f"Probabilidad de brote la semana siguiente a {sem_lbl}")
    a.plotly_chart(fig, width="stretch")
    d = df[df["municipio"] == mun].copy()
    d["fecha"] = d["anio"].astype(str) + "-S" + d["semana"].astype(str).str.zfill(2)
    d = d[d["t"] <= anio * 100 + sem].tail(104)
    f2 = px.line(d, x="fecha", y="casos", title=f"Casos semanales – {mun} (últimas 104 semanas)")
    f2.add_hline(y=float(d["umbral_brote"].iloc[-1]), line_dash="dash", line_color="red", annotation_text="umbral de brote (p75)")
    b.plotly_chart(f2, width="stretch")
    row = snap[snap["municipio"] == mun]
    if len(row):
        b.metric(f"Riesgo de brote en {mun}", f"{row['prob_brote'].iloc[0]:.0%}")
    st.dataframe(snap[["municipio", "casos", "Lluvia", "Temp", "Historial", "prob_brote"]].sort_values("prob_brote", ascending=False),
                 width="stretch", hide_index=True)

with tab2:
    st.subheader("Validación temporal (entrenamiento < 2023, prueba ≥ 2023)")
    rows = [{"Modelo": k, **v} for k, v in metrics.items() if isinstance(v, dict)]
    mdf = pd.DataFrame(rows)
    st.dataframe(mdf, hide_index=True, width="stretch")
    st.plotly_chart(px.bar(mdf.melt(id_vars="Modelo", value_vars=["AUC", "F1"]), x="Modelo", y="value", color="variable", barmode="group",
                           title="Red bayesiana vs. líneas base"), width="stretch")
    st.markdown("**Estructura:** Lluvia, Temp → Clima → Brote ← Temporada, Historial")
    st.subheader("CPT aprendida: P(Brote | Clima, Temporada, Historial)")
    st.dataframe(bn.cpt_table("Brote"), hide_index=True, width="stretch")

with tab3:
    if "agent" not in st.session_state:
        st.session_state.agent = Agent(Tools(bn, df))
        st.session_state.chat = []
    ag = st.session_state.agent
    st.caption(f"Modo del agente: **{ag.mode}** (defina LLM_API_KEY para usar el LLM). Herramientas: get_risk, get_cases, search_docs.")
    for role, content, trace in st.session_state.chat:
        with st.chat_message(role):
            st.markdown(content)
            if trace:
                with st.expander("Herramientas llamadas"):
                    for t in trace:
                        st.json({"tool": t[0], "args": t[1], "obs": t[2]}, expanded=False)
    q = st.chat_input(f"Ej.: ¿Cuál es el riesgo de brote en {mun}? / ¿Qué es el canal endémico?")
    if q:
        st.session_state.chat.append(("user", q, None))
        with st.spinner("Pensando…"):
            out = ag.run(q)
        st.session_state.chat.append(("assistant", out["answer"], out["trace"]))
        st.rerun()
