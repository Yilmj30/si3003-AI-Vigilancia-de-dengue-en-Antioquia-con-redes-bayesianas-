# Resumen: Protocolo de vigilancia en salud pública de dengue (INS)
Fuente a citar: Instituto Nacional de Salud (INS), Protocolo de Vigilancia en Salud Pública – Dengue (códigos de evento 210 dengue, 220 dengue grave, 580 mortalidad por dengue). Documento oficial: https://www.ins.gov.co (Buscador de eventos > Dengue). NOTA DEL EQUIPO: este archivo es un resumen redactado por el equipo; agregar el PDF oficial en docs/ para que el RAG lo indexe.

## Objetivo de la vigilancia
Identificar oportunamente los cambios en el comportamiento del dengue (aumento de casos, brotes, casos graves y muertes) para orientar acciones de prevención y control del vector Aedes aegypti.

## Clasificación clínica
El protocolo distingue dengue sin signos de alarma, dengue con signos de alarma y dengue grave. Los signos de alarma incluyen dolor abdominal intenso, vómito persistente, sangrado de mucosas, letargo e irritabilidad. Los casos con signos de alarma y graves requieren atención hospitalaria. Este sistema NO es una guía clínica: ante síntomas se debe consultar al servicio de salud.

## Notificación
La notificación de casos probables es semanal (semana epidemiológica) a través de SIVIGILA; los casos de dengue grave y las muertes son de notificación inmediata.
