# Resumen: Análisis de comportamiento, canal endémico y definición de brote
Fuente a citar: INS – Boletín Epidemiológico Semanal (BES) y metodología de canal endémico usada en los informes de evento de dengue. https://www.ins.gov.co/buscador-eventos/Paginas/Vista-Boletin-Epidemilogico.aspx . NOTA DEL EQUIPO: resumen propio.

## Canal endémico
El canal endémico compara los casos de cada semana epidemiológica con el comportamiento histórico (generalmente varios años previos) del mismo periodo. Las zonas habituales son: éxito, seguridad, alerta y brote/epidemia. Cuando los casos observados superan el límite superior esperado, la situación se clasifica como brote o situación de alerta.

## Uso en este proyecto
El proyecto aproxima el umbral de brote con el percentil 75 de los casos semanales históricos de cada municipio (calculado solo con datos de entrenamiento). Es una simplificación del canal endémico oficial.

## Rezago de los datos
Los datos de SIVIGILA tienen rezago de notificación y ajustes posteriores; las últimas semanas suelen estar subnotificadas.
