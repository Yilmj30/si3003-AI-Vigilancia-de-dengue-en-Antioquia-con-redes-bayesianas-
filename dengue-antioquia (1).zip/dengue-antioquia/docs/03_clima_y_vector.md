# Resumen: Clima, estacionalidad y Aedes aegypti
Fuente a citar: OPS/OMS – Dengue: hojas informativas y guías de control vectorial (https://www.paho.org/es/temas/dengue); IDEAM – datos de precipitación y temperatura (http://dhime.ideam.gov.co). NOTA DEL EQUIPO: resumen propio.

## Relación clima–transmisión
La lluvia aumenta los criaderos (recipientes con agua) y la temperatura alta acelera el ciclo del mosquito y la replicación viral. El efecto sobre los casos aparece con un rezago aproximado de 2 a 6 semanas. Por eso el modelo usa lluvia y temperatura promedio de las semanas t-3 a t-5.

## Municipios de mayor riesgo en Antioquia
Los municipios cálidos por debajo de unos 1.800 m s. n. m. (Urabá, Bajo Cauca, Magdalena Medio, Occidente cercano y el Valle de Aburrá) tienen condiciones para Aedes aegypti. En municipios altos y fríos el riesgo es bajo.

## Prevención comunitaria
Eliminar recipientes que acumulen agua, lavar y tapar tanques, usar toldillo y repelente, y permitir las acciones de control de la secretaría de salud.
