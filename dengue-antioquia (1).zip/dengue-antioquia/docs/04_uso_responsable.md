# Uso responsable de esta herramienta
Fuente: equipo del proyecto (SI3003 – IA, EAFIT 2026).
Esta es una herramienta analítica académica de apoyo a la vigilancia, no una guía clínica ni un sistema oficial de alertas. Usa únicamente datos agregados por municipio y semana, nunca datos individuales. Las probabilidades de riesgo dependen de la calidad y el rezago de los datos de SIVIGILA e IDEAM. Las decisiones de salud pública corresponden a la Secretaría Seccional de Salud de Antioquia y al INS.
