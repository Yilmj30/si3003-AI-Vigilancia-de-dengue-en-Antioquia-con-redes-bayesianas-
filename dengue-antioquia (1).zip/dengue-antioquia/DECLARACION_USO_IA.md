# Declaración de uso de IA generativa

Integrantes: María José Holguín · Mateo Aristizábal · Mariana Patiño

| Herramienta | Propósito | Alcance |
|---|---|---|
| Claude (Anthropic) | Generar el esqueleto inicial del código (red bayesiana con eliminación de variables, loop del agente, RAG TF-IDF, dashboard Streamlit), los resúmenes del corpus en `docs/` y la redacción de este README. | El equipo revisó, ejecutó y es responsable del código y los resultados. |
| LLM del agente (Groq / NVIDIA NIM, vía API compatible con OpenAI) | Componente de la solución: razona y llama herramientas en el chat. | Solo en ejecución. |

El equipo debe completar aquí qué partes modificó, entendió y validó cada integrante.
