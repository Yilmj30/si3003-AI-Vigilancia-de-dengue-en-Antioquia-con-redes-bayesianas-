# Vigilancia de dengue en Antioquia con redes bayesianas (Tema 3.4)
**SI3003 – Inteligencia Artificial, EAFIT 2026-1 · Proyecto final integrador**

Integrantes: María José Holguín · Mateo Aristizábal · Mariana Patiño

Estima la probabilidad de **brote de dengue la próxima semana** por municipio de Antioquia a partir de clima rezagado, estacionalidad e historial de casos, y la expone en un dashboard con un **agente LLM con RAG** que consulta el riesgo y cita protocolos.

> ⚠️ Herramienta analítica académica, **no es guía clínica** ni sistema oficial de alertas. Solo usa **datos agregados** municipio-semana; nunca datos individuales.

## Cómo correrlo
```bash
pip install -r requirements.txt
python -m src.model            # entrena, valida y guarda data/processed/metricas.json
python -m eval.eval_agent      # evaluación del agente (13 preguntas) -> eval/resultados_agente.csv
streamlit run app.py           # dashboard
```
Agente con LLM (opcional; sin clave funciona en **modo offline** con las mismas herramientas):
```bash
export LLM_API_KEY="tu_clave_groq"   # o NVIDIA NIM / Ollama
export LLM_BASE_URL="https://api.groq.com/openai/v1"   # por defecto
export LLM_MODEL="llama-3.3-70b-versatile"             # por defecto
```

## Datos
| Fuente | Uso | Cómo obtenerla |
|---|---|---|
| **SIVIGILA / INS** – eventos 210 (dengue) y 220 (dengue grave) | casos por municipio y semana epidemiológica | Portal SIVIGILA (microdatos) o datos.gov.co ("vigilancia en salud pública"). Guardar como `data/raw/sivigila_<año>.csv`: el código filtra Antioquia y **agrega de inmediato** a conteos municipio-semana. |
| **IDEAM (DHIME)** / **SIATA** | precipitación y temperatura | Agregar por municipio-semana en `data/raw/clima_municipio_semana.csv` (`municipio, anio, semana, precipitacion_mm, temperatura_c`). |
| Alternativa directa | — | `data/raw/dengue_antioquia.csv` con `municipio, anio, semana, casos, precipitacion_mm, temperatura_c`. |

**Plan B / estado actual:** si `data/raw/` está vacío, la app usa `data/processed/sample_synthetic.csv`, una muestra **sintética** generada por `src/generate_sample_data.py` solo para probar el pipeline, y la marca con un aviso rojo. **Las métricas reportadas deben recalcularse con los datos reales antes de la entrega.**

## Parte 1 – Red bayesiana (implementación propia, `src/bayes_net.py`)
```
Lluvia ─┐
        ├─> Clima ─┐
Temp ───┘          │
Temporada ─────────┼─> Brote (casos semana t+1 > p75 histórico del municipio)
Historial ─────────┘
```
- Lluvia/Temp: promedio de las semanas t-3…t-5 vs. mediana municipal (alta/baja).
- Temporada: semanas 1–13 y 40–53 (pico) vs. otra. Historial: casos recientes > umbral.
- CPTs por máxima verosimilitud con suavizado de Laplace; inferencia exacta por **eliminación de variables** sobre factores (evidencia faltante se marginaliza).
- **Validación temporal:** entrenamiento < 2023, prueba ≥ 2023; umbrales calculados solo con entrenamiento (sin fuga).
- **Líneas base:** persistencia (brote esta semana ⇒ brote la próxima) y tasa histórica municipal; **ablación** sin clima. Métricas: AUC, F1, Brier (`data/processed/metricas.json` y pestaña "Modelo" del dashboard).

## Parte 2 – Agente LLM con RAG (`src/agent.py`, `src/rag.py`)
- Loop agéntico manual con **Tmáx = 6** iteraciones; errores de herramientas vuelven como observación.
- Herramientas: `get_risk(municipio)`, `get_cases(municipio, semanas)`, `search_docs(query)`.
- RAG: fragmentos de 120 palabras (solape 30) de `docs/` (.md/.txt/.pdf) con recuperación TF-IDF + coseno. **Agregar los PDF oficiales del INS (protocolo de dengue, BES) en `docs/`**: se indexan automáticamente.
- Respuestas con citas `[archivo]`.

## Dashboard (`app.py`)
Selección de municipio, semana epidemiológica y escenario climático ("qué pasaría si"); mapa de riesgo por municipio, serie semanal con umbral de brote, tabla de ranking, métricas vs. línea base, CPT aprendida y chat con traza de herramientas.

## Evaluación del agente
`eval/resultados_agente.csv`: 13 preguntas fijas con herramienta esperada, herramienta llamada y si citó fuente. Resultado en modo offline: 12/13 herramienta correcta, 13/13 con cita (falla esperada: municipio fuera de cobertura, "Bogotá").

## Limitaciones
- Rezago y subnotificación de SIVIGILA en las últimas semanas.
- Umbral p75 es una simplificación del canal endémico oficial del INS.
- Cobertura de 22 municipios con coordenadas aproximadas de cabecera.
- Variables discretizadas en 2 niveles: se pierde información; Naive Bayes / más niveles son trabajo futuro.
- Corpus RAG actual = resúmenes del equipo; deben complementarse con los documentos oficiales.

## Estructura
```
app.py · requirements.txt · DECLARACION_USO_IA.md
src/ data.py  bayes_net.py  model.py  rag.py  agent.py  generate_sample_data.py
docs/ corpus RAG · eval/ eval_agent.py, resultados_agente.csv · data/raw (reales) · data/processed
```
